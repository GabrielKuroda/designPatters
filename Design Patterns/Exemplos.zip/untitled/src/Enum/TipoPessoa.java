package Enum;

public enum TipoPessoa {
    PESSOA_FISICA,PESSOA_JURIDICA
}
