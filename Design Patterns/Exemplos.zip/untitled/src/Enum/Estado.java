package Enum;

public enum Estado {
    SP,MG,RJ,ES
}
