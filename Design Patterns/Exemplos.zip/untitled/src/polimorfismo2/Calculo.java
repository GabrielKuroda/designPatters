package polimorfismo2;

public interface Calculo {

    void calcular(int x,int y);

}
