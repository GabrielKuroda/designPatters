package polimorfismo;

public class MilkShake implements Bebida{

    public void preparar(int quantia){

        System.out.println("Preparando um MilkShake com quantia de: "+ quantia + "ml");

    }

}
