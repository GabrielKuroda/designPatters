package polimorfismo;

public class Bebidaa {

    public void preparar(int quantia){

        System.out.println("Preparando uma Bebida com quantia de: "+ quantia + "ml");

    }

}
