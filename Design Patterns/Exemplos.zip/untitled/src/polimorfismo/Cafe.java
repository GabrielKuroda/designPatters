package polimorfismo;

public class Cafe extends Bebidaa{


}
