package polimorfismo;

public class Cha extends Bebidaa{

    public void preparar(int quantia){

        System.out.println("Aquecendo " + quantia + "ml de aguá");

    }


}
