package polimorfismo;

public interface Bebida {

    void preparar(int var);

}
